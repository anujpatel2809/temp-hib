package com.infy;

public class DriverClass {

	public static void main(String[] args) {
		MovieDAO dao = new MovieDAO();
		System.out.println("==========================");
		dao.getAllMovies().forEach(m -> System.out.println(m));
		System.out.println("==========================\nDisplay moviename and release year in descending order");
		dao.getMovieNameAndReleaseYearDesc()
			.forEach(o -> System.out.println(o[0] + " - " + o[1]));
		System.out.println("==========================\nFind the maximum revenue in the given language");
		System.out.println("Max Revenu for English is "+dao.getMaxRevenuInLanguage("english"));
		System.out.println("==========================\nFind the sum of revenue in the given language");
		System.out.println("Sum of Revenu for English is "+dao.getSumRevenuInLanguage("english"));
		System.out.println("==========================\nFind the count of distinct languages");
		System.out.println("Total distinct language "+dao.getDistinctLanguageCount());
		System.out.println("==========================\nFetch the movie names that does not have the word �Home� in it. Perform case insensitive search");
		dao.getMovieNameThatDoseNotContainHOME()
			.forEach(o -> System.out.println(o));
		System.out.println("==========================\nList the different languages available");
		dao.getDistinctLanguage()
			.forEach(o -> System.out.println(o));
		System.out.println("==========================\nList the movie details which are either in the given language or has revenue greater than or equal to the given value");
		dao.getMovieInGivenLangAndRevMoreThenGiven("english",168000002)
			.forEach(o -> System.out.println(o));
		System.out.println("==========================\nList the movie details which released between 1990 and 2010, and has revenue greater than 10 million");
		dao.getMovieBet1920And2010WithRevGT10M()
			.forEach(o -> System.out.println(o));
		System.out.println("==========================List the director details, whose bornIn field is not null");
		dao.getDirectorWhoseBornInIsKnown()
			.forEach(o -> System.out.println(o));
		System.out.println("==========================\nDisplay the number of movies in each language");
		dao.getMovieCountInEachLangage()
			.forEach(o -> System.out.println(o[0] + " - " + o[1]));
		System.out.println("==========================Get all movie details of specified language");
		dao.getMovie("english")
			.forEach(o -> System.out.println(o));
			
	}

}
