package com.infy;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class MovieDAO {

	public List<MovieEntity> getAllMovies() {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();

		List list = session.createCriteria(MovieEntity.class).list();

		session.close();
		return list;
	}

	public List<Object[]> getMovieNameAndReleaseYearDesc() {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List list = session
				.createCriteria(MovieEntity.class).setProjection(Projections.projectionList()
						.add(Projections.property("movieName")).add(Projections.property("releasedIn")))
				.addOrder(Order.desc("movieName")).list();

		session.close();

		return list;
	}

	public Integer getMaxRevenuInLanguage(String language) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<Integer> list = session.createCriteria(MovieEntity.class).add(Restrictions.ilike("language", language))
				.setProjection(Projections.max("revenueInDollars")).list();
		session.close();
		return list.get(0);
	}

	public Long getSumRevenuInLanguage(String language) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<Long> list = session.createCriteria(MovieEntity.class).add(Restrictions.ilike("language", language))
				.setProjection(Projections.sum("revenueInDollars")).list();
		session.close();
		return list.get(0);
	}
	
	public Long getDistinctLanguageCount() {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<Long> list = session.createCriteria(MovieEntity.class)
				.setProjection(Projections.countDistinct("language")).list();
		session.close();
		return list.get(0);
	}
	
	public List<String> getMovieNameThatDoseNotContainHOME() {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List list = session
				.createCriteria(MovieEntity.class)
				.add(Restrictions.not(Restrictions.ilike("movieName", "%home%")))
				.setProjection(Projections.property("movieName"))
				.list();

		session.close();

		return list;
	}
	
	public List<String> getDistinctLanguage() {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<String> list = session.createCriteria(MovieEntity.class)
				.setProjection(Projections.distinct(Projections.property("language")))
				.list();
		session.close();
		return list;
	}
	
	public List<String> getMovieInGivenLangAndRevMoreThenGiven(String language,Integer revanue) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<String> list = session.createCriteria(MovieEntity.class)
				.add(Restrictions.or(Restrictions.ilike("language", language),Restrictions.ge("revenueInDollars", revanue)))
				.setProjection(Projections.property("movieName"))
				.list();
		session.close();
		return list;
	}
	
	public List<String> getMovieBet1920And2010WithRevGT10M() {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<String> list = session.createCriteria(MovieEntity.class)
				.add(Restrictions.and(Restrictions.between("releasedIn", 1990, 2010),Restrictions.ge("revenueInDollars", 10000000)))
				.setProjection(Projections.property("movieName"))
				.list();
		session.close();
		return list;
	}
	
	public List<DirectorEntity> getDirectorWhoseBornInIsKnown() {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<DirectorEntity> list = session.createCriteria(DirectorEntity.class)
				.add(Restrictions.isNotNull("bornIn"))
				.list();
		session.close();
		return list;
	}
	
	public List<Object[]> getMovieCountInEachLangage() {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<Object[]> list = session.createCriteria(MovieEntity.class)
				.setProjection(Projections.projectionList()
						.add(Projections.groupProperty("language"))
						.add(Projections.count("language")))
				.list();
		session.close();
		return list;
	}
	
	public List<MovieEntity> getMovie(String language) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		List<MovieEntity> list = session.createCriteria(MovieEntity.class)
				.add(Restrictions.ilike("language", language))
				.list();
		session.close();
		return list;
	}
}
