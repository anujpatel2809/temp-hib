package com.infy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DrivingLicenseDAO {

	public Integer addRecords(Drivingicense driviningLicense) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(driviningLicense);
		session.getTransaction().commit();
		return id;
	}

	public Drivingicense read(Integer rollNo) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		Drivingicense student = (Drivingicense) session.get(Drivingicense.class, rollNo);

		return student;
	}

}
