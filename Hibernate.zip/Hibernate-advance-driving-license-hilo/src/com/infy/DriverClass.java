package com.infy;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DriverClass {
	
	public static void main(String[] args) {
		DrivingLicenseDAO dao=new DrivingLicenseDAO();
		System.out.println(dao.addRecords(new Drivingicense("A", 12, "F", "A", new Date(), new Date(), "In")));
		System.out.println(dao.addRecords(new Drivingicense("B", 12, "F", "A", new Date(), new Date(), "In")));
		System.out.println(dao.addRecords(new Drivingicense("C", 12, "F", "A", new Date(), new Date(), "In")));
		System.out.println(dao.addRecords(new Drivingicense("D", 12, "F", "A", new Date(), new Date(), "In")));
		System.out.println(dao.addRecords(new Drivingicense("E", 12, "F", "A", new Date(), new Date(), "In")));
	}

}
