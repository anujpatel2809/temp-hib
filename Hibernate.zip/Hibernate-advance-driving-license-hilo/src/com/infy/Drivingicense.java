package com.infy;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity(name = "Driving_License")
@GenericGenerator(name="hilogen",strategy="hilo",parameters= {@Parameter(name="max_lo",value="3")})
public class Drivingicense {

	@Id
	@Column(name = "LicenseNumber")
	@GeneratedValue(generator="hilogen")
	Integer licenseNumber;
	@Column(name = "Name")
	String name;
	@Column(name = "Age")
	Integer age;
	@Column(name = "Gender")
	String gender;
	@Column(name = "Address")
	String address;
	@Temporal(TemporalType.DATE)
	@Column(name = "LicenseIssueDate")
	Date licenseIssueDate;
	@Temporal(TemporalType.DATE)
	@Column(name = "LicenseExpiryDate")
	Date licenseExpiryDate;
	@Column(name = "LicenseIssueZone")
	String licenseIssueZone;
	public Drivingicense(String name, Integer age, String gender, String address,
			Date licenseIssueDate, Date licenseExpiryDate, String licenseIssueZone) {
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.address = address;
		this.licenseIssueDate = licenseIssueDate;
		this.licenseExpiryDate = licenseExpiryDate;
		this.licenseIssueZone = licenseIssueZone;
	}

	
}
