package com.infy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class ClassRoomAllocationDAO {

	public Integer addTraineeAlone(TraineeEntity student) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(student);
		session.getTransaction().commit();
		return id;
	}
	
	public Integer addClassroomAlone(ClassRoomEntity classroom) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(classroom);
		session.getTransaction().commit();
		return id;
	}

	public Integer addTraineeWithClassroom(TraineeEntity traineeEntity,ClassRoomEntity classroomEntity) {
		traineeEntity.setClassRoom(classroomEntity);
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(traineeEntity);
		session.getTransaction().commit();
		return id;
		
	}
	
	public void allocateClassroom(Integer trainee,Integer classroom) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		ClassRoomEntity classroomEntity = (ClassRoomEntity) session.get(ClassRoomEntity.class, classroom);
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		traineeEntity.setClassRoom(classroomEntity);
		session.beginTransaction();
		session.update(traineeEntity);
		session.getTransaction().commit();
	}
	
	/*
	 * public void dealocateClassroom(Integer trainee) { SessionFactory sessionFacroty
	 * = HibernateUtil.getSessionFacroty(); Session session =
	 * sessionFacroty.openSession(); TraineeEntity traineeEntity = (TraineeEntity)
	 * session.get(TraineeEntity.class, trainee); traineeEntity.setClassRoom(null);
	 * session.beginTransaction(); session.update(traineeEntity);
	 * session.getTransaction().commit(); }
	 */
	
	public void deleteTraineeOnly(Integer trainee) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		traineeEntity.setClassRoom(null);
		session.beginTransaction();
		session.delete(traineeEntity);
		session.getTransaction().commit();	
	}
	
	public TraineeEntity getAllocationDetails(Integer trainee) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		return traineeEntity;	
	}

}
