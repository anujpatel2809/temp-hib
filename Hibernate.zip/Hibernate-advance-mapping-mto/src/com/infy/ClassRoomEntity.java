package com.infy;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ClassRoomEntity {

	@Id
	private Integer classRoomId;
	private Integer seatingCapacity;

	public ClassRoomEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClassRoomEntity(Integer classRoomId, Integer seatingCapacity) {
		super();
		this.classRoomId = classRoomId;
		this.seatingCapacity = seatingCapacity;
	}

	public Integer getClassRoomId() {
		return classRoomId;
	}

	public void setClassRoomId(Integer classRoomId) {
		this.classRoomId = classRoomId;
	}

	public Integer getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(Integer seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

	@Override
	public String toString() {
		return "ClassRoomEntity [classRoomId=" + classRoomId + ", seatingCapacity=" + seatingCapacity + "]";
	}

}
