package com.infy;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class TraineeEntity {

	@Id
	private Integer id;
	private String name;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="m_id")
	private ClassRoomEntity classRoom;

	public TraineeEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TraineeEntity(Integer id, String name, ClassRoomEntity desktop) {
		super();
		this.id = id;
		this.name = name;
		this.classRoom = desktop;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ClassRoomEntity getClassRoom() {
		return classRoom;
	}

	public void setClassRoom(ClassRoomEntity classRoom) {
		this.classRoom = classRoom;
	}

	@Override
	public String toString() {
		return "TraineeEntity [id=" + id + ", name=" + name + ", desktop=" + classRoom + "]";
	}

}
