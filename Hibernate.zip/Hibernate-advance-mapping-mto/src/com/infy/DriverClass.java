package com.infy;

public class DriverClass {
	
	public static void main(String[] args) {
		ClassRoomAllocationDAO dao=new ClassRoomAllocationDAO();
//		System.out.println(dao.addTraineeWithClassroom(new TraineeEntity(1, "A", null), new ClassRoomEntity(1, 30)));
//		System.out.println(dao.addTraineeWithClassroom(new TraineeEntity(2, "B", null), new ClassRoomEntity(2, 30)));
//		
//		System.out.println(dao.addTraineeAlone(new TraineeEntity(3, "C", null)));
//		System.out.println(dao.addClassroomAlone(new ClassRoomEntity(3, 50)));
		
//		dao.allocateClassroom(3, 1);
		
//		dao.deleteTraineeOnly(2);
		
	}

}
