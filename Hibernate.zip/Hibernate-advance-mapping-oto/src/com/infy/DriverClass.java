package com.infy;

public class DriverClass {
	
	public static void main(String[] args) {
		DesktopAllocationDAO dao=new DesktopAllocationDAO();
		System.out.println(dao.addTraineeWithDestop(new TraineeEntity(1, "A", null), new DesktopEntity(1, "Dell")));
		System.out.println(dao.addTraineeWithDestop(new TraineeEntity(2, "B", null), new DesktopEntity(2, "HP")));
		
		System.out.println(dao.addTraineeAlone(new TraineeEntity(3, "C", null)));
		System.out.println(dao.addDesktopAlone(new DesktopEntity(3, "Lenovo")));
		
//		dao.allocateDesktop(3, 3);
		
//		dao.dealocateDesktop(3);
		
//		dao.deleteTraineeOnly(2);
		
//		dao.deleteTraineeWithDestop(1);
	}

}
