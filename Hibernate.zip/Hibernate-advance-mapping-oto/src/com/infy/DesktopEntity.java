package com.infy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DesktopEntity {

	@Id
	@Column(name="m_id")
	private Integer machineId;
	private String make;

	public DesktopEntity(Integer machineEntity, String make) {
		super();
		this.machineId = machineEntity;
		this.make = make;
	}

	public DesktopEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getMachineEntity() {
		return machineId;
	}

	public void setMachineEntity(Integer machineEntity) {
		this.machineId = machineEntity;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	@Override
	public String toString() {
		return "DesktopEntity [machineEntity=" + machineId + ", make=" + make + "]";
	}

}
