package com.infy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DesktopAllocationDAO {

	public Integer addTraineeAlone(TraineeEntity student) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(student);
		session.getTransaction().commit();
		return id;
	}
	
	public Integer addDesktopAlone(DesktopEntity desktop) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(desktop);
		session.getTransaction().commit();
		return id;
	}

	public Integer addTraineeWithDestop(TraineeEntity traineeEntity,DesktopEntity desktopEntity) {
		traineeEntity.setDesktop(desktopEntity);
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(traineeEntity);
		session.getTransaction().commit();
		return id;
		
	}
	
	public void allocateDesktop(Integer trainee,Integer destop) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		DesktopEntity desktopEntity = (DesktopEntity) session.get(DesktopEntity.class, destop);
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		traineeEntity.setDesktop(desktopEntity);
		session.beginTransaction();
		session.update(traineeEntity);
		session.getTransaction().commit();
	}
	
	public void dealocateDesktop(Integer trainee) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		traineeEntity.setDesktop(null);
		session.beginTransaction();
		session.update(traineeEntity);
		session.getTransaction().commit();
	}
	
	public void deleteTraineeOnly(Integer trainee) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		traineeEntity.setDesktop(null);
		session.beginTransaction();
		session.delete(traineeEntity);
		session.getTransaction().commit();	
	}
	
	public void deleteTraineeWithDestop(Integer trainee) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		session.beginTransaction();
		session.delete(traineeEntity);
		session.getTransaction().commit();	
	}
	
	public TraineeEntity getAllocationDetails(Integer trainee) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		TraineeEntity traineeEntity = (TraineeEntity) session.get(TraineeEntity.class, trainee);
		return traineeEntity;	
	}

}
