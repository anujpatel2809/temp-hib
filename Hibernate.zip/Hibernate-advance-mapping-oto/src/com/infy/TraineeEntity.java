package com.infy;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class TraineeEntity {

	@Id
	private Integer id;
	private String name;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="m_id",unique=true)
	private DesktopEntity desktop;

	public TraineeEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TraineeEntity(Integer id, String name, DesktopEntity desktop) {
		super();
		this.id = id;
		this.name = name;
		this.desktop = desktop;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DesktopEntity getDesktop() {
		return desktop;
	}

	public void setDesktop(DesktopEntity desktop) {
		this.desktop = desktop;
	}

	@Override
	public String toString() {
		return "TraineeEntity [id=" + id + ", name=" + name + ", desktop=" + desktop + "]";
	}

}
