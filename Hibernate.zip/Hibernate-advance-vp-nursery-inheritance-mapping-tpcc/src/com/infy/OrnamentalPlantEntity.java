package com.infy;

import javax.persistence.Entity;

@Entity
public class OrnamentalPlantEntity extends PlantEntity {
	private String flowerColor;

	public OrnamentalPlantEntity() {
	}

	public OrnamentalPlantEntity(String plantName, String kind, String flowerColor) {
		super(plantName, kind);
		this.flowerColor = flowerColor;
	}

	public String getFlowerColor() {
		return flowerColor;
	}

	public void setFlowerColor(String flowerColor) {
		this.flowerColor = flowerColor;
	}

	@Override
	public String toString() {
		return "OrnamentalPlantEntity [flowerColor=" + flowerColor + "]";
	}

}
