package com.infy;

public class DriverClass {
	
	public static void main(String[] args) {
		PlantsDAO dao=new PlantsDAO();
		System.out.println(dao.addPlant(new PlantEntity("P1", "K1")));
		System.out.println(dao.addPlant(new MedicinalPlantEntity("MP1","K1", "Root")));
		System.out.println(dao.addPlant(new OrnamentalPlantEntity("OP1", "K1", "red")));
		
		System.out.println(dao.getPlant("OP1"));
		System.out.println(dao.getPlant("MP1"));
	}

}
