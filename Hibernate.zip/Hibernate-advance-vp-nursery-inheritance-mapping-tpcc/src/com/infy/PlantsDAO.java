package com.infy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class PlantsDAO {

	public String addPlant(PlantEntity entity) {
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		session.save(entity);
		session.getTransaction().commit();
		return entity.getPlantName();
	}
	
	public PlantEntity getPlant(String plantName){
		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		PlantEntity plant = (PlantEntity) session.get(PlantEntity.class, plantName);
		if(plant instanceof MedicinalPlantEntity)
			return (MedicinalPlantEntity) plant;
		else
			return (OrnamentalPlantEntity) plant;
	}

}
