package com.infy;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("MedicinalPlant")
public class MedicinalPlantEntity extends PlantEntity {

	private String usefulPart;

	public MedicinalPlantEntity() {
	}

	public MedicinalPlantEntity(String plantName, String kind, String usefulPart) {
		super(plantName, kind);
		this.usefulPart = usefulPart;
	}

	public String getUsefulPart() {
		return usefulPart;
	}

	public void setUsefulPart(String usefulPart) {
		this.usefulPart = usefulPart;
	}

	@Override
	public String toString() {
		return "MedicinalPlantEntity [usefulPart=" + usefulPart + "]";
	}

}
