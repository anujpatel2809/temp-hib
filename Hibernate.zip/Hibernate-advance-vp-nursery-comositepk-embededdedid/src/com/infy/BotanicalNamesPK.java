package com.infy;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class BotanicalNamesPK implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String genericName;
	private String speciesName;

	public BotanicalNamesPK(String genericName, String speciesName) {
		super();
		this.genericName = genericName;
		this.speciesName = speciesName;
	}

	public BotanicalNamesPK() {
	}

	public String getGenericName() {
		return genericName;
	}

	public void setGenericName(String genericName) {
		this.genericName = genericName;
	}

	public String getSpeciesName() {
		return speciesName;
	}

	public void setSpeciesName(String speciesName) {
		this.speciesName = speciesName;
	}

	@Override
	public String toString() {
		return "BotanicalNamesPK [genericName=" + genericName + ", speciesName=" + speciesName + "]";
	}

}
