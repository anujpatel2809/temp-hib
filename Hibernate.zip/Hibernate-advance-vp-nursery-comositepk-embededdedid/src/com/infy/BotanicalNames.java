package com.infy;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
public class BotanicalNames {

	@EmbeddedId
	private BotanicalNamesPK pk;
	private String family;
	private String commonName;

	public BotanicalNames() {
	}

	public BotanicalNames(BotanicalNamesPK pk, String family, String commonName) {
		super();
		this.pk = pk;
		this.family = family;
		this.commonName = commonName;
	}

	public BotanicalNamesPK getPk() {
		return pk;
	}

	public void setPk(BotanicalNamesPK pk) {
		this.pk = pk;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	@Override
	public String toString() {
		return "BotanicalNames [pk=" + pk + ", family=" + family + ", commonName=" + commonName + "]";
	}

}
