package com.infy;

public class DriverClass {
	
	public static void main(String[] args) {
		BotanicalNamesDAO dao=new BotanicalNamesDAO();
		System.out.println(dao.addRecords(new BotanicalNames(new BotanicalNamesPK("GN1", "SN3"), "FM1", "CN1")));
		System.out.println(dao.addRecords(new BotanicalNames(new BotanicalNamesPK("GN3", "SN2"), "FM1", "CN1")));
		System.out.println(dao.addRecords(new BotanicalNames(new BotanicalNamesPK("GN2", "SN3"), "FM1", "CN1")));
		
		System.out.println(dao.read(new BotanicalNamesPK("GN1", "SN1")));
		
	}

}
