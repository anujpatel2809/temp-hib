package com.infy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class BotanicalNamesDAO {

	public BotanicalNamesPK addRecords(BotanicalNames names) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		BotanicalNamesPK id = (BotanicalNamesPK) session.save(names);
		session.getTransaction().commit();
		return id;
	}

	public BotanicalNames read(BotanicalNamesPK rollNo) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		BotanicalNames student = (BotanicalNames) session.get(BotanicalNames.class, rollNo);

		return student;
	}

}
