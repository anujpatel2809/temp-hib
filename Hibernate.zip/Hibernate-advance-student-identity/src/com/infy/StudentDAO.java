package com.infy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class StudentDAO {

	public Integer addRecords(Student student) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(student);
		session.getTransaction().commit();
		return id;
	}

	public Student read(Integer rollNo) {

		SessionFactory sessionFacroty = HibernateUtil.getSessionFacroty();
		Session session = sessionFacroty.openSession();
		Student student = (Student) session.get(Student.class, rollNo);

		return student;
	}

}
