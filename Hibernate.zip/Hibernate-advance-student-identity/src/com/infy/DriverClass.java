package com.infy;

public class DriverClass {
	
	public static void main(String[] args) {
		System.out.println(new StudentDAO().addRecords(new Student("Anuj", 12, "6B", "Pune")));
		
	}

}
