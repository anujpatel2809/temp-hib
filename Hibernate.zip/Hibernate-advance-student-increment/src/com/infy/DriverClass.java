package com.infy;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DriverClass {
	
	public static void main(String[] args) {
		System.out.println(new StudentDAO().addRecords(new Student("Anuj", 12, "6B", "Pune")));
		
	}

}
