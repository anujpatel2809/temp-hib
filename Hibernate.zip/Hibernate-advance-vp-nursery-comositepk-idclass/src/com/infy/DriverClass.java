package com.infy;

public class DriverClass {
	
	public static void main(String[] args) {
		BotanicalNamesDAO dao=new BotanicalNamesDAO();
		System.out.println(dao.addRecords(new BotanicalNames("GN1", "SN1", "FM1", "CN1")));
		System.out.println(dao.addRecords(new BotanicalNames("GN2", "SN1", "FM1", "CN1")));
		System.out.println(dao.addRecords(new BotanicalNames("GN2", "SN2", "FM1", "CN1")));
		
		System.out.println(dao.read(new BotanicalNamesPK("GN2", "SN2")));
		
	}

}
